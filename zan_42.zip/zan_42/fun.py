import pygame
pygame.init()

def get_color(color):

	colors = {
		"red": (255, 0, 0),
		"pink": (248, 24, 148),
		"blue": (0, 0, 255),
		"green": (0, 255, 0),
		"yellow": (255, 255, 0)
	}

	return colors[color]

class Npc:

	def __init__(self, image, color, game):
		self.image = image
		self.my_color = color
		self.my_index = 0

		self.money = 500

		self.go_step = 0

		self.color = get_color(color)

		self.Game = game

	def draw(self, screen):

		rect = self.Game.areas[self.my_index].rect
		
		if self.my_color == "red":
			center = (rect.x + 10, rect.y + 10)
		elif self.my_color == "pink":
			center = (rect.center[0] - 20, rect.bottom - 20)
		elif self.my_color == "blue":
			center = (rect.center[0] + 5, rect.center[1] - 20)
		elif self.my_color == "green":
			center = (rect.center)
		elif self.my_color == "yellow":
			center = (rect.center[0] + 20, rect.center[1])

		screen.blit(self.image, self.image.get_rect(center=center))
