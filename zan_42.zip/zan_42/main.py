# cd D:\Python\Скрипты\Вольтяшка\группа_2\zan_42 & D: & python main.py

from random import randint

import pygame
pygame.init()

from fun import *
import all_areas

class Game:

	def __init__(self):
		self.screen = pygame.display.set_mode((790, 790))
		self.clock = pygame.time.Clock()

		self.all_colors = ["red", "pink", "blue", "green", "yellow"]

		self.areas = all_areas.get_all_cards()

		self.load_images()
		self.render_txt()
		self.load_sound()

		self.red_npc = Npc(self.fishka_1, "red", self)
		self.pink_npc = Npc(self.fishka_2, "pink", self)
		self.blue_npc = Npc(self.fishka_3, "blue", self)
		self.green_npc = Npc(self.fishka_4, "green", self)
		self.yellow_npc = Npc(self.fishka_5, "yellow", self)

		self.all_fishki = {
			"red": self.red_npc,
			"pink": self.pink_npc,
			"blue": self.blue_npc,
			"green": self.green_npc,
			"yellow": self.yellow_npc
		}
		self.my_color = "green"
		self.my_hod = False
		self.bought = None
		self.wait_bought = False

		self.queue = 0

		self.go_step_temp = 0

		self.tick_to_step = 100
		self.move_number = 0
		self.info_txt = pygame.Surface((0, 0))

		self.debug_status = False
		self.loop = 1

	def load_images(self):
		self.map = pygame.image.load("map.png").convert()
		self.domik_1 = pygame.image.load("domik_1.png").convert_alpha()
		self.domik_2 = pygame.image.load("domik_2.png").convert_alpha()
		self.fishka_1 = pygame.image.load("fishka_1.png").convert_alpha()
		self.fishka_2 = pygame.image.load("fishka_2.png").convert_alpha()
		self.fishka_3 = pygame.image.load("fishka_3.png").convert_alpha()
		self.fishka_4 = pygame.image.load("fishka_4.png").convert_alpha()
		self.fishka_5 = pygame.image.load("fishka_5.png").convert_alpha()
		self.karta_1 = pygame.image.load("karta_1.png").convert()
		self.karta_2 = pygame.image.load("karta_2.png").convert()
		self.karta_3 = pygame.image.load("karta_3.png").convert()

	def render_txt(self):
		#self.font_15 = pygame.font.Font("PixelOperator.ttf", 15)
		self.font_13 = pygame.font.Font("wow.ttf", 13)
		self.font_15 = pygame.font.Font("wow.ttf", 15)
		self.font_22 = pygame.font.Font("wow.ttf", 22)

		self.txt_queue = self.font_15.render("QUEUE", False, (255, 255, 255))

		self.txt_queue_color = []

		for txt in self.all_colors:
			self.txt_queue_color.append(
				(self.font_13.render(txt, False, (255, 255, 255)), self.font_15.render(txt, False, (0, 255, 0)))
			)

	def load_sound(self):
		self.sound_hod = pygame.mixer.Sound("hod.mp3")
		self.sound_kush = pygame.mixer.Sound("kush.wav")

	def update_info_txt(self, txt):
		self.info_txt = self.font_22.render(txt, False, (255, 255, 255))


	def debug_info(self):
		if not self.debug_status: return

		self.debug_status = False

		area = self.areas[self.my_index]


	def draw_frame(self):
		for area in self.areas:
			self.screen.blit(area.surface, (area.rect))

		for key in self.all_fishki:
			self.all_fishki[key].draw(self.screen)

		self.screen.blit(self.txt_queue, (705, 3))

		for index, surf in enumerate(self.txt_queue_color, start=1):
			self.screen.blit(surf[index - 1 == self.move_number], (705, index * 16))

		self.screen.blit(self.info_txt, self.info_txt.get_rect(center=(395, 750)))

		my_money = self.all_fishki[self.my_color].money

		txt_money = self.font_22.render(f"My money: {my_money}р", False, (255, 255, 255))

		self.screen.blit(pygame.transform.rotate(txt_money, -90), (705, 430))

	def step(self):

		npc = self.all_fishki[self.all_colors[self.move_number]]

		buy = False

		area = self.areas[npc.my_index]

		if npc.go_step != 0:
			npc.go_step -= 1
			npc.my_index += 1
			self.go_step_temp = 0

			if npc.my_index >= len(self.areas):
				npc.my_index %= len(self.areas)
				npc.money += 150
				self.sound_kush.play()
				self.update_info_txt(f"{npc.my_color} прошел круг +150")

			self.sound_hod.play()

			pygame.time.delay(150)
			#pygame.time.delay(50)

			area = self.areas[npc.my_index]

			self.update_info_txt(f"{npc.my_color} останавливается в '{area.name}'")

			if not area.allow_buy:

				if npc.go_step == 0:
					self.wait_bought = False

					if area.my_master != None:

						if npc.money >= area.price:
							npc.money -= area.price
							self.all_fishki[area.my_master].money += npc.money

							self.update_info_txt(f"{npc.my_color} заплатил {area.price} игроку {self.all_fishki[area.my_master].my_color}")

						else:

							self.update_info_txt(f"{npc.my_color} заплатил {npc.money} игроку {self.all_fishki[area.my_master].my_color}")

							self.all_fishki[area.my_master].money += npc.money
							npc.money = 0

						self.sound_kush.play()

			if area.allow_buy and npc.my_color != self.my_color and npc.go_step == 0 and npc.money >= area.price and randint(1, 10) > 7:
				buy = True

			if area.name in ("Тюрьма", "Отправляйтесь в тюрьму") and npc.go_step == 0:
				npc.money -= 50
				self.update_info_txt(f"{npc.my_color} в тюрме, короче -50")

				self.sound_kush.play()

			elif area.name == "Налог"and npc.go_step == 0:
				npc.money -= 50
				self.update_info_txt(f"{npc.my_color} в налоге, короче -50")

				self.sound_kush.play()

			elif area.name == "Сверхналог"and npc.go_step == 0:
				npc.money -= 200
				self.update_info_txt(f"{npc.my_color} пу пу пу -200")

				self.sound_kush.play()

			elif area.name == "Общественная казна"and npc.go_step == 0:
				npc.money += 100
				self.update_info_txt(f"{npc.my_color} в общ. казне, короче +100")

				self.sound_kush.play()

			elif area.name == "Шанс"and npc.go_step == 0:

				if randint(0, 1):
					npc.money += 100
					self.update_info_txt(f"{npc.my_color} повезло повезло +100")
				else:
					npc.money -= 100
					self.update_info_txt(f"{npc.my_color} НЕ повезло повезло -100")

				self.sound_kush.play()


		if not self.bought is None:
			buy = self.bought
			self.bought = None

		elif self.bought is None and npc.my_color == self.my_color and area.allow_buy:
			self.update_info_txt(f"A - купить {self.areas[npc.my_index].name}, D - скип")

		if buy:

			area.allow_buy = False
			npc.money -= area.price
			area.my_master = npc.my_color

			area.surface_fill((*npc.color, 100))

			self.update_info_txt(f"{npc.my_color} покупаект '{area.name}'")

			self.sound_kush.play()

			pygame.time.delay(50)

	def update_step(self):
		self.move_number = (self.move_number + 1) % len(self.all_colors)

		npc = self.all_fishki[self.all_colors[self.move_number]]

		self.my_hod = npc.my_color == self.my_color

		if not self.my_hod:
			npc.go_step = randint(1, 6) + randint(1, 6)
		else:
			self.update_info_txt("Ваш ход, нажмите пробел для броска кубика")


	def start(self):
		while self.loop:
			
			self.clock.tick(60)

			self.events = pygame.event.get()

			for ev in self.events:

				if ev.type == pygame.KEYDOWN:

					if ev.key == pygame.K_SPACE and self.my_hod:

						npc = self.all_fishki[self.my_color]

						if self.go_step_temp == 0:
							random_step = randint(1, 6)
							self.update_info_txt(f"Выпала грань {random_step}, кидайте второй кубик")
							#npc.go_step += random_step
							self.go_step_temp = random_step

						else:
							self.update_info_txt(f"Выпала грань {random_step}, ваша сумма: {npc.go_step + random_step}")
							npc.go_step += random_step + self.go_step_temp

							self.my_hod = False
							self.wait_bought = True


					elif ev.key == pygame.K_a and self.wait_bought:
						self.bought = True
						self.wait_bought = False

						self.update_info_txt(f"покупка бро")

					elif ev.key == pygame.K_d and self.wait_bought:
						self.bought = False
						self.wait_bought = False

						self.update_info_txt(f"скип бро")

				elif ev.type == pygame.QUIT:
					self.loop = 0

			self.screen.fill((30, 33, 61))

			self.screen.blit(self.map, (0, 0))
			self.draw_frame()

			if not (self.my_hod or self.wait_bought):
				self.tick_to_step -= 1
				if self.tick_to_step == 0:
					self.tick_to_step = 300
					self.update_step()

			self.step()

			pygame.display.flip()


if __name__ == "__main__":
	Game().start()
