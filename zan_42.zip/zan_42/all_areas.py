import pygame; pygame.init()

class BlockArea:

	def __init__(self, rect, allow_buy, price, name):
		self.rect = pygame.Rect(rect)
		self.allow_buy = allow_buy
		self.price = price
		self.name = name
		self.my_master = None

		self.surface = pygame.Surface(self.rect[2:], pygame.SRCALPHA)

	def surface_fill(self, color):
		self.surface.fill(color)

def get_all_cards():
	return (
		BlockArea((606, 605, 100, 100), False, 0, "Старт"),

		BlockArea((550, 605, 56, 100), True, 60, "Тюмень"),
		BlockArea((494, 605, 56, 100), False, 0, "Общественная казна"),
		BlockArea((437, 605, 56, 100), True, 60, "Самара"),
		BlockArea((381, 605, 56, 100), False, 0, "Налог"),
		BlockArea((325, 605, 56, 100), True, 200, "Железная дорога 1"),
		BlockArea((268, 605, 56, 100), True, 100, "Калуга"),
		BlockArea((212, 605, 56, 100), False, 0, "Шанс"),
		BlockArea((156, 605, 56, 100), True, 100, "Пермь"),
		BlockArea((99, 605, 56, 100), True, 120, "Томск"),

		BlockArea((0, 605, 100, 100), False, 0, "Тюрьма"),

		BlockArea((0, 548, 100, 56), True, 140, "Уфа"),
		BlockArea((0, 492, 100, 56), False, 0 , "Общественная казна"),
		BlockArea((0, 436, 100, 56), True, 140, "Казань"),
		BlockArea((0, 380, 100, 56), True, 160, "Краснодар"),
		BlockArea((0, 323, 100, 56), True, 200, "Железная дорога 2"),
		BlockArea((0, 267, 100, 56), True, 180, "Архангельск"),
		BlockArea((0, 211, 100, 56), False, 0, "Общественная казна"),
		BlockArea((0, 154, 100, 56), True, 180, "Челябинск"),
		BlockArea((0, 98, 100, 56), True, 200, "Нижний Новгород"),

		BlockArea((0, 0, 100, 100), False, 0, "Бесплатная стоянка"),

		BlockArea((99, 0, 56, 100), True, 220, "Омск"),
		BlockArea((156, 0, 56, 100), False, 0, "Шанс"),
		BlockArea((212, 0, 56, 100), True, 220,"Волгоград"),
		BlockArea((268, 0, 56, 100), False, 0, "Шанс"),
		BlockArea((325, 0, 56, 100), True, 200, "Железная дорога 3"),
		BlockArea((381, 0, 56, 100), True, 260, "Ставрополь"),
		BlockArea((437, 0, 56, 100), True, 260, "Тверь"),
		BlockArea((494, 0, 56, 100), False, 0, "Общественная казна"),
		BlockArea((550, 0, 56, 100), True, 280, "Хабаровск"),

		BlockArea((608, 0, 100, 100), False, 0, "Отправляйтесь в тюрьму"),

		BlockArea((607, 99, 100, 56), True, 300, "Екатеринбург"),
		BlockArea((607, 154, 100, 56), True, 300, "Владивосток"),
		BlockArea((607, 211, 100, 56), False, 0, "Шанс"),
		BlockArea((607, 267, 100, 56), True, 320, "Санкт-Петербург"),
		BlockArea((607, 323, 100, 56), True, 200, "Железная дорога 4"),
		BlockArea((607, 380, 100, 56), False, 0, "Шанс"),
		BlockArea((607, 436, 100, 56), True, 350, "Москва"),
		BlockArea((607, 492, 100, 56), False, 0, "Сверхналог"),
		BlockArea((607, 548, 100, 56), True, 400, "Новосибирск")
	)
